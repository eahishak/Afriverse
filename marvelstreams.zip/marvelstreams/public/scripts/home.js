document.addEventListener('DOMContentLoaded', fetchHomeContent);
