document.addEventListener('DOMContentLoaded', fetchSeries);
